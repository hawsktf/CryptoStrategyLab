source LiveTradingBots/code/.venv/bin/activate
python3 LiveTradingBots/code/strategies/envelope/run.py
