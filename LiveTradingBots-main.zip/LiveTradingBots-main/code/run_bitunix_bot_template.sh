source LiveTradingBots/code/.venv/bin/activate
python3 LiveTradingBots/code/strategies/bitunix_bot_template/run.py
